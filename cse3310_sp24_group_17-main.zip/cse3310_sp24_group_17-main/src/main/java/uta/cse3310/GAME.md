Usage For Game

Create Game: 
---------example: Game e1 = new Game(filepath, numOfwords, size)

Get gameID: 
----------e1.getGameId(); --> returns int

words in the matrix:
----------getNumofWords(); --> returns number of words present in the matrix

CHECK: 
----------check_ans(startRow, startCol, endRow,endCol) --> Reurns True/False

NOTE: All Internal Variables are Private
