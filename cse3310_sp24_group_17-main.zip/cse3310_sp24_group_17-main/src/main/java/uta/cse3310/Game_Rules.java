package uta.cse3310;

public class Game_Rules {
    private String[] rules;
    public static final int MIN_LENGTH_WORD = 3;
    public static final int MAX_CONCURRENT_GAMES = 5;
}
